<?php
/**
 * Fuel
 *
 * Fuel is a fast, lightweight, community driven PHP5 framework.
 *
 * @package		Fuel
 * @version		1.0
 * @author		Harro "WanWizard" Verton
 * @license		MIT License
 * @copyright	2010 Dan Horrigan
 * @link		http://fuelphp.com
 */

namespace Fuel\App;

return array(
	'salt'			=> 'sup3rs3Cr3tk3y564'				// Encryption salt. Make sure to update this to something random!!!!
);

/* End of file config/encrypt.php */
