<?php

return array(
	'driver' => 'simpleauth',
	'verify_multiple_logins' => false,
);